-- drop temp table created in 2012080700.sql
DROP TABLE IF EXISTS tmp_users;
