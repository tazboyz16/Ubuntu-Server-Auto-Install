<!DOCTYPE html>
<html>

<link rel="stylesheet" type="text/css" href="/css/wowindex.css">

<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<body>

<br><br><br><br>

<div style="width: 100%;">
   <div style="float:left; width: 80%; font-size:360%; color: red; font-family: Hordefont;"> Feast or
   </div>
   <div style="float:right; font-size:440%; color: Blue; font-family: Alliancefont;"> Howling
   </div>
</div>
<div style="clear:both"></div>
<div style="width: 100%;">
   <div style="float:left; width: 80%; font-size:360%; color: red; font-family: Hordefont;"> Famine
   </div>
   <div style="float:right; font-size:440%; color: Blue; font-family: Alliancefont;"> Fury
   </div>
</div>
<div style="clear:both"></div>

<br>

<p align= "center"><img src="/images/backgrounds/wow main background.jpg" alt="" usemap="#map" />
<map name="map">
    <area shape="rect" coords="820, 0, 1155, 402" href="/doomhammer/doomhammerforums/" />
    <area shape="rect" coords="-1, 3, 362, 405" href="/blackrock/blackrockforums/" />
</map>

</body>
	</html>
